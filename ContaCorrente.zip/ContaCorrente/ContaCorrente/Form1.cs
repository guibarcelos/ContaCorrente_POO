﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContaCorrente
{
    public partial class FrmContaCorrente : Form
    {
        public FrmContaCorrente()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            //Desabilitar dados de entrada:
            txtNumConta.Enabled     = false;
            txtNomeTitular.Enabled  = false;
            txtSaldoAtual.Enabled   = false;

            //Dados de entrada:
            string numeroConta = txtNumConta.Text;
            string nomeTitular = txtNomeTitular.Text;
            double saldo = double.Parse(txtSaldoAtual.Text);
            double valor = double.Parse(txtValor.Text);

            //Processamento:
            if (rdbDeposito.Checked == true)        //ou apenas: if (rdbDeposito.Checked)
            {
                saldo = saldo + valor;      //ou apenas: saldo += valor;
            }
            else if (rdbRetirada.Checked == true)
            {
                saldo = saldo - valor;      //ou apenas: saldo -= valor;
            }

            //Saída:
            txtSaldoAtual.Text = saldo.ToString("N2");
        }

        private void btnNovaConta_Click(object sender, EventArgs e)
        {
            //Habilitar novamente dados de entrada:
            txtNumConta.Enabled     = true;
            txtNomeTitular.Enabled  = true;
            txtSaldoAtual.Enabled   = true;

            txtNumConta.Clear();
            txtNomeTitular.Clear();
            txtSaldoAtual.Text  = "0";
            txtValor.Text       = "0";
            rdbDeposito.Checked = false;
            rdbRetirada.Checked = false;
        }

        private void txtSaldoAtual_Leave(object sender, EventArgs e)
        {
            txtSaldoAtual.Text = Convert.ToDouble(txtSaldoAtual.Text).ToString("N2");
        }
    }
}
