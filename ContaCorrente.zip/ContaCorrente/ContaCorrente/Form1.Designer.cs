﻿
namespace ContaCorrente
{
    partial class FrmContaCorrente
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNumConta = new System.Windows.Forms.Label();
            this.lblNomeTitular = new System.Windows.Forms.Label();
            this.lblSaldo = new System.Windows.Forms.Label();
            this.txtNumConta = new System.Windows.Forms.TextBox();
            this.txtNomeTitular = new System.Windows.Forms.TextBox();
            this.pnlDadosConta = new System.Windows.Forms.Panel();
            this.txtSaldoAtual = new System.Windows.Forms.TextBox();
            this.grpMovimentacao = new System.Windows.Forms.GroupBox();
            this.txtValor = new System.Windows.Forms.TextBox();
            this.lblValor = new System.Windows.Forms.Label();
            this.rdbRetirada = new System.Windows.Forms.RadioButton();
            this.rdbDeposito = new System.Windows.Forms.RadioButton();
            this.btnExecutar = new System.Windows.Forms.Button();
            this.btnNovaConta = new System.Windows.Forms.Button();
            this.pnlDadosConta.SuspendLayout();
            this.grpMovimentacao.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNumConta
            // 
            this.lblNumConta.AutoSize = true;
            this.lblNumConta.Location = new System.Drawing.Point(8, 13);
            this.lblNumConta.Name = "lblNumConta";
            this.lblNumConta.Size = new System.Drawing.Size(93, 13);
            this.lblNumConta.TabIndex = 0;
            this.lblNumConta.Text = "Número da Conta:";
            // 
            // lblNomeTitular
            // 
            this.lblNomeTitular.AutoSize = true;
            this.lblNomeTitular.Location = new System.Drawing.Point(8, 49);
            this.lblNomeTitular.Name = "lblNomeTitular";
            this.lblNomeTitular.Size = new System.Drawing.Size(85, 13);
            this.lblNomeTitular.TabIndex = 1;
            this.lblNomeTitular.Text = "Nome do Titular:";
            // 
            // lblSaldo
            // 
            this.lblSaldo.AutoSize = true;
            this.lblSaldo.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaldo.Location = new System.Drawing.Point(124, 87);
            this.lblSaldo.Name = "lblSaldo";
            this.lblSaldo.Size = new System.Drawing.Size(91, 31);
            this.lblSaldo.TabIndex = 2;
            this.lblSaldo.Text = "Saldo:";
            // 
            // txtNumConta
            // 
            this.txtNumConta.Location = new System.Drawing.Point(130, 10);
            this.txtNumConta.Name = "txtNumConta";
            this.txtNumConta.Size = new System.Drawing.Size(144, 20);
            this.txtNumConta.TabIndex = 3;
            // 
            // txtNomeTitular
            // 
            this.txtNomeTitular.Location = new System.Drawing.Point(130, 46);
            this.txtNomeTitular.Name = "txtNomeTitular";
            this.txtNomeTitular.Size = new System.Drawing.Size(283, 20);
            this.txtNomeTitular.TabIndex = 4;
            // 
            // pnlDadosConta
            // 
            this.pnlDadosConta.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlDadosConta.Controls.Add(this.txtSaldoAtual);
            this.pnlDadosConta.Controls.Add(this.txtNomeTitular);
            this.pnlDadosConta.Controls.Add(this.lblNumConta);
            this.pnlDadosConta.Controls.Add(this.lblNomeTitular);
            this.pnlDadosConta.Controls.Add(this.txtNumConta);
            this.pnlDadosConta.Controls.Add(this.lblSaldo);
            this.pnlDadosConta.Location = new System.Drawing.Point(12, 12);
            this.pnlDadosConta.Name = "pnlDadosConta";
            this.pnlDadosConta.Size = new System.Drawing.Size(428, 134);
            this.pnlDadosConta.TabIndex = 6;
            // 
            // txtSaldoAtual
            // 
            this.txtSaldoAtual.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSaldoAtual.ForeColor = System.Drawing.Color.Blue;
            this.txtSaldoAtual.Location = new System.Drawing.Point(215, 87);
            this.txtSaldoAtual.Name = "txtSaldoAtual";
            this.txtSaldoAtual.Size = new System.Drawing.Size(198, 38);
            this.txtSaldoAtual.TabIndex = 5;
            this.txtSaldoAtual.Text = "0";
            this.txtSaldoAtual.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtSaldoAtual.Leave += new System.EventHandler(this.txtSaldoAtual_Leave);
            // 
            // grpMovimentacao
            // 
            this.grpMovimentacao.Controls.Add(this.txtValor);
            this.grpMovimentacao.Controls.Add(this.lblValor);
            this.grpMovimentacao.Controls.Add(this.rdbRetirada);
            this.grpMovimentacao.Controls.Add(this.rdbDeposito);
            this.grpMovimentacao.Location = new System.Drawing.Point(12, 151);
            this.grpMovimentacao.Name = "grpMovimentacao";
            this.grpMovimentacao.Size = new System.Drawing.Size(427, 94);
            this.grpMovimentacao.TabIndex = 7;
            this.grpMovimentacao.TabStop = false;
            this.grpMovimentacao.Text = "Movimentação Bancária:";
            // 
            // txtValor
            // 
            this.txtValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.txtValor.Location = new System.Drawing.Point(217, 23);
            this.txtValor.Multiline = true;
            this.txtValor.Name = "txtValor";
            this.txtValor.Size = new System.Drawing.Size(198, 49);
            this.txtValor.TabIndex = 3;
            this.txtValor.Text = "0";
            this.txtValor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblValor
            // 
            this.lblValor.AutoSize = true;
            this.lblValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValor.Location = new System.Drawing.Point(126, 28);
            this.lblValor.Name = "lblValor";
            this.lblValor.Size = new System.Drawing.Size(85, 31);
            this.lblValor.TabIndex = 2;
            this.lblValor.Text = "Valor:";
            // 
            // rdbRetirada
            // 
            this.rdbRetirada.AutoSize = true;
            this.rdbRetirada.Location = new System.Drawing.Point(10, 60);
            this.rdbRetirada.Name = "rdbRetirada";
            this.rdbRetirada.Size = new System.Drawing.Size(65, 17);
            this.rdbRetirada.TabIndex = 1;
            this.rdbRetirada.TabStop = true;
            this.rdbRetirada.Text = "Retirada";
            this.rdbRetirada.UseVisualStyleBackColor = true;
            // 
            // rdbDeposito
            // 
            this.rdbDeposito.AutoSize = true;
            this.rdbDeposito.Location = new System.Drawing.Point(10, 28);
            this.rdbDeposito.Name = "rdbDeposito";
            this.rdbDeposito.Size = new System.Drawing.Size(67, 17);
            this.rdbDeposito.TabIndex = 0;
            this.rdbDeposito.TabStop = true;
            this.rdbDeposito.Text = "Depósito";
            this.rdbDeposito.UseVisualStyleBackColor = true;
            // 
            // btnExecutar
            // 
            this.btnExecutar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnExecutar.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExecutar.Location = new System.Drawing.Point(12, 251);
            this.btnExecutar.Name = "btnExecutar";
            this.btnExecutar.Size = new System.Drawing.Size(189, 51);
            this.btnExecutar.TabIndex = 4;
            this.btnExecutar.Text = "Executar";
            this.btnExecutar.UseVisualStyleBackColor = false;
            this.btnExecutar.Click += new System.EventHandler(this.btnExecutar_Click);
            // 
            // btnNovaConta
            // 
            this.btnNovaConta.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnNovaConta.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNovaConta.Location = new System.Drawing.Point(250, 251);
            this.btnNovaConta.Name = "btnNovaConta";
            this.btnNovaConta.Size = new System.Drawing.Size(189, 51);
            this.btnNovaConta.TabIndex = 8;
            this.btnNovaConta.Text = "Nova Conta";
            this.btnNovaConta.UseVisualStyleBackColor = false;
            this.btnNovaConta.Click += new System.EventHandler(this.btnNovaConta_Click);
            // 
            // FrmContaCorrente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(446, 308);
            this.Controls.Add(this.btnNovaConta);
            this.Controls.Add(this.btnExecutar);
            this.Controls.Add(this.grpMovimentacao);
            this.Controls.Add(this.pnlDadosConta);
            this.Name = "FrmContaCorrente";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Conta Corrente";
            this.pnlDadosConta.ResumeLayout(false);
            this.pnlDadosConta.PerformLayout();
            this.grpMovimentacao.ResumeLayout(false);
            this.grpMovimentacao.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblNumConta;
        private System.Windows.Forms.Label lblNomeTitular;
        private System.Windows.Forms.Label lblSaldo;
        private System.Windows.Forms.TextBox txtNumConta;
        private System.Windows.Forms.TextBox txtNomeTitular;
        private System.Windows.Forms.Panel pnlDadosConta;
        private System.Windows.Forms.GroupBox grpMovimentacao;
        private System.Windows.Forms.TextBox txtValor;
        private System.Windows.Forms.Label lblValor;
        private System.Windows.Forms.RadioButton rdbRetirada;
        private System.Windows.Forms.RadioButton rdbDeposito;
        private System.Windows.Forms.Button btnExecutar;
        private System.Windows.Forms.Button btnNovaConta;
        private System.Windows.Forms.TextBox txtSaldoAtual;
    }
}

